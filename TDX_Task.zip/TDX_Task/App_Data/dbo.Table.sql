﻿CREATE TABLE [dbo].[Table]
(
	[Transaction_GUID] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY, 
    [PersonID] INT NOT NULL, 
    [FirstName] VARCHAR(50) NULL, 
    [LastName] VARCHAR(50) NULL, 
    [DateOfPurchase] DATETIME NOT NULL, 
    [Transaction_Value] FLOAT NULL
)

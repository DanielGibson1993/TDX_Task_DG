﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TDX_Task
{
    public partial class TDX_View : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //This code will connect to an SQL DB and return data depending on the transaction GUID.
        protected void SaleID_Button_Click(object sender, EventArgs e)
        {
            // I had an issue with the webconfig and could not get this to work, but some tests I did had thise code working on a different SQL DB.
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TDXSQL"].ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand($"SELECT PersonID, DateOfPurchase, Transaction_Value FROM Sales_Headers WHERE Transaction_GUID = {SaleID_Text.Text}", conn))
                {
                    conn.Open();
                    var reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {                        
                        var SPID = reader["PersonID"].ToString();
                        var DOP = reader["DateOfPurchase"].ToString();
                        var TV = reader["Transaction_Value"].ToString();
                        SaleID_PersonID_Text.Text = SPID;
                        Date_Text.Text = DOP;
                        TransactionValue_Text.Text = TV;
                    }
                    else
                    {
                        Label1.Text = "Sale ID not found";
                    }
                }
            }
        }
    }
}
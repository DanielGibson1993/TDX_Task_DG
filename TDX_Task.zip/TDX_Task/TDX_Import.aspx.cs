﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;


namespace TDX_Task
{
    public partial class TDX_Import : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Import_Button_Click(object sender, EventArgs e)
        {
            string path = "C:\\Upload\\" + FileUpload1.FileName;
            if (FileUpload1.HasFile)
            {
                //Unfortunately I could not get the upload process to work
            }
            else
            {
                Label1.Text = "No file selected";
            }
        }
    }
}